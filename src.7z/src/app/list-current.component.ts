import { Component } from '@angular/core';
import { NgModule } from '@angular/core';
@Component({
  selector: 'list-current',
 // template: `
    //<button (click)="onClickMe()">List Current Heroes</button>
   // {{clickMessage}}{{list}}`
   template: `<div class="card card-block"
   *ngFor="let hero of herolist">
<button id="btn" (click)=onClickMe(hero)>{{hero.name}}</button><br>

<!--<p class="card-text"
   >{{hero.universe}}</p>
<button (click)="onClickMe(hero)">{{hero.universe}}</button>-->

</div>

<div>
<select ng-model="DropDownComponent" (change)=displayUni($event) >
<option ng-repeat="hero in herolist" value="{{hero.name}}">{{hero.name}}</option>
</select>
<p><span>You selected: </span><b>{{heroname}}</b></p>
</div>`
})
export class ClickMeComponent {
  clickMessage = '';
  herolist:Object[] ;
  constructor(){
    this.herolist = [{name:'superman',universe:"DC"},
                {name:'batman',universe:"DC"},
                {name:'he-man', universe:"unknown"},
              {name: 'captain america', universe:"Marvel"}];
  }

  onClickMe(hero) {
    
    alert(hero.universe)
    //this.clickMessage = 'Display all heroes';
    
  }
}

export class DropDownComponent{
  heroname ='';
  herolist:Object[] ;
  constructor(){
    this.herolist = [{name:'superman',universe:"DC"},
                {name:'batman',universe:"DC"},
                {name:'he-man', universe:"unknown"},
              {name: 'captain america', universe:"Marvel"}];
  }
  displayUniverse(hero){
    alert(hero.universe)
  }
  displayUni (event: any) {
    //update the ui
    this.heroname=event.target.value;
  }
}